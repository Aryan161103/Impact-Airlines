function fun()
{
    alert("Please Enter all the Details for our convenience");
}